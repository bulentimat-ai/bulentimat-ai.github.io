# Bülent İmat — Apps, Books & Visual Stories

A two-language (English/Turkish) static personal portfolio. Built for GitHub Pages with no build process, backend, tracker, external font or CDN requirement. All code and published media are local files.

## What's included

- 22 ready-to-serve HTML pages: English at `/` and Turkish at `/tr/`, including Books, Apps, Visual Stories, About, Contact and Privacy.
- Original author-supplied front/back cover artwork for the two books.
- **Only the author-approved PDF previews:** `awooo-chronicles-preview.pdf` (4 pages) and `awooo-the-tale-of-a-husky-preview.pdf` (6 pages).
- Gentian and İsviçre Rotam product showcases with actual supplied screenshots and links to their official websites.
- Instagram profile links for `@bulentimat` and `@guneythehusky`.
- Responsive design, keyboard-accessible image lightbox, English/Turkish navigation, optional dark theme, descriptive meta titles and basic SEO metadata.

**Not included:** Full 32-page or 59-page source PDFs, EPUB book files, paid book download links, fake store/author profiles, private contact details, external analytics.

## Publish on GitHub Pages

1. Download and unzip the `bulent-imat-portfolio-github-pages.zip` archive.
2. On GitHub, create a new **public** repository for this portfolio (for example `bulentimat-portfolio`).
3. Upload **the extracted files and folders** to the repository's root, including `index.html`, `tr/`, `apps/`, `books/`, `assets/` and `.nojekyll`. Do **not** upload the ZIP itself as a single file.
4. In repository **Settings → Pages**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then save.
5. When GitHub shows your Pages URL, visit it and test EN/TR, PDF previews, app galleries and external links.
6. If you buy a custom domain, configure it in GitHub Pages settings and your domain registrar's DNS panel. A domain has not been assumed or registered here.

Typical project Pages URLs have the form `https://<username>.github.io/<repository>/`; the exact URL depends on your actual repository.

For an offline local preview (from inside the extracted folder):

```bash
python3 -m http.server 8000
```

Open `http://localhost:8000/` in your browser.

## Updating book store links later

The book links deliberately say **coming soon** because the public Amazon/Apple Books URLs had not been provided. Do not link to the private KDP dashboard. Once the books have public product URLs, update the relevant book page in both language trees or edit the optional editable source package (`build.py`, `BOOKS` values `amazon=None` / `apple=None`) and regenerate the site. Do not enable Apple Books links during a Kindle exclusivity period unless the distribution terms allow it.

The Amazon Author Central and Apple Books author-profile placeholders on the Books listing are intentionally inactive until their public links exist.

## Adding individual Instagram Reels later

The site links to the user's two public Instagram profiles. Individual Reels were not provided and no fake posts or video URLs have been created. Add curated video links when those URLs are available. Video binaries are not hosted on GitHub Pages.

## Design and privacy

The included images are author-supplied. Some images have been resized and converted to WebP for performance. The original front/back cover artwork and layout have not been redesigned. The public preview PDFs are page-exact slices of the provided source PDFs.

The site has no backend or contact form, does not load third-party embeds and does not set tracking cookies. Light/dark theme uses only the browser's local storage for appearance preference. External pages follow the policies of their own operators.

## Project release status

**This is a complete, deployable website package but is not yet published to an external domain.** GitHub repo creation, Pages activation and custom-domain configuration require a repository under your account.
