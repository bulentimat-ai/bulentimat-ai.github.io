/* Zero-dependency portfolio interactions: accessible menu, appearance preference, photo viewer. */
(()=>{
'use strict';
const doc=document,root=doc.documentElement;
const themeBtn=doc.querySelector('.theme-toggle');
const updateTheme=()=>{if(themeBtn){themeBtn.setAttribute('aria-pressed',root.dataset.theme==='dark'?'true':'false');themeBtn.querySelector('.theme-symbol').textContent=root.dataset.theme==='dark'?'☀':'◐';}};
updateTheme();
themeBtn?.addEventListener('click',()=>{root.dataset.theme=root.dataset.theme==='dark'?'light':'dark';try{localStorage.setItem('bi-theme',root.dataset.theme);}catch(e){}updateTheme();});
const menuBtn=doc.querySelector('.menu-toggle'),nav=doc.querySelector('#main-nav');
const closeMenu=()=>{nav?.classList.remove('open');menuBtn?.setAttribute('aria-expanded','false');};
menuBtn?.addEventListener('click',()=>{const opened=nav.classList.toggle('open');menuBtn.setAttribute('aria-expanded',String(opened));});
nav?.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
doc.addEventListener('click',e=>{if(nav&&!nav.contains(e.target)&&!menuBtn?.contains(e.target))closeMenu();});
const modal=doc.getElementById('lightbox');
if(!modal)return;
const photo=modal.querySelector('img'),caption=modal.querySelector('figcaption');
const triggers=[...doc.querySelectorAll('.gallery-trigger')];
let currentGroup=[],current=0,previousFocus=null;
function show(n){if(!currentGroup.length)return;current=(n+currentGroup.length)%currentGroup.length;const b=currentGroup[current];photo.src=b.dataset.full;photo.alt=b.dataset.caption||b.querySelector('img')?.alt||'';caption.textContent=b.dataset.caption||photo.alt;const many=currentGroup.length>1;modal.querySelector('.lightbox-prev').hidden=!many;modal.querySelector('.lightbox-next').hidden=!many;}
function openModal(btn){previousFocus=doc.activeElement;currentGroup=triggers.filter(b=>b.dataset.gallery===btn.dataset.gallery);show(currentGroup.indexOf(btn));modal.setAttribute('aria-hidden','false');doc.body.classList.add('modal-open');modal.querySelector('.lightbox-close').focus();}
function closeModal(){modal.setAttribute('aria-hidden','true');doc.body.classList.remove('modal-open');photo.removeAttribute('src');previousFocus?.focus();}
triggers.forEach(b=>b.addEventListener('click',()=>openModal(b)));
modal.querySelector('.lightbox-close').addEventListener('click',closeModal);
modal.querySelector('.lightbox-prev').addEventListener('click',()=>show(current-1));
modal.querySelector('.lightbox-next').addEventListener('click',()=>show(current+1));
modal.addEventListener('click',e=>{if(e.target===modal)closeModal();});
doc.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMenu();if(modal.getAttribute('aria-hidden')==='false')closeModal();}if(modal.getAttribute('aria-hidden')==='false'){if(e.key==='ArrowLeft')show(current-1);if(e.key==='ArrowRight')show(current+1);if(e.key==='Tab'){const buttons=[...modal.querySelectorAll('button:not([hidden])')];const start=buttons[0],end=buttons.at(-1);if(e.shiftKey&&doc.activeElement===start){e.preventDefault();end.focus();}else if(!e.shiftKey&&doc.activeElement===end){e.preventDefault();start.focus();}}}});
let touchStart=null;
modal.addEventListener('touchstart',e=>{touchStart=e.changedTouches[0]?.screenX;},{passive:true});
modal.addEventListener('touchend',e=>{if(touchStart===null)return;const diff=e.changedTouches[0].screenX-touchStart;if(Math.abs(diff)>55)show(current+(diff<0?1:-1));touchStart=null;},{passive:true});
})();
